<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

//Route::middleware('auth:api')->get('/user', function (Request $request) {
    //return $request->user();
//});


Route::group(['middleware' => 'api', 'prefix' => 'auth', 'namespace' => 'Api'], function () {
    Route::post('login', 'AuthController@login');
    Route::post('signup', 'AuthController@create');
    Route::post('logout', 'AuthController@logout');
    Route::post('refresh', 'AuthController@refresh');
    Route::post('me', 'AuthController@me');
    Route::post('forgot-password', 'AuthController@forgotPassword');
    Route::post('reset-password', 'AuthController@doResetPassword');
    Route::post('verify-email', 'AuthController@doVerifyEmail');
    Route::post('sociallogin', 'AuthController@social_login');
});

Route::group(['middleware' => ['api'], 'namespace' => 'Api'], function () {

    //Route::get('users', 'UsersController@index');
    Route::get('users/{id}', 'UsersController@show');
    //Route::post('users', 'UsersController@create');
    Route::put('users/location', 'UsersController@updateLocation');
    Route::put('users/update_type', 'UsersController@updateType');
    Route::put('users/gender', 'UsersController@updateGender');
    Route::put('users/profile', 'UsersController@updateProfile');
    Route::put('users/customerprofile', 'UsersController@updateCustomerProfile');
    Route::post('users/photos', 'MediaController@PhotosPost');
    Route::delete('photos/{id}', 'MediaController@destroy');
    
    Route::put('users/about', 'UsersController@updateAbout');
    
    Route::post('user_list', 'UsersController@swipe');
	
    Route::get('nearbypeople', 'UsersController@nearbypeople');
	
    Route::post('nearbyrestaurant', 'RestaurantController@nearbyrestaurants');
	
    Route::post('nearbytaxi', 'TaxiController@nearbytaxis');
    Route::post('mettup', 'MeetupController@create');
    
    Route::post('locations', 'LocationsController@create');
    Route::get('locations', 'LocationsController@index');
    
    Route::post('like', 'LikeController@create');
    Route::delete('dislike/{id}', 'LikeController@destroy');
    
});