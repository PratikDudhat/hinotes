<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Auth::routes(['register' => false]);

Route::get('/forgot', function () { return view('auth.passwords.email'); });
Route::post('reset_password', 'Auth\ForgotPasswordController@passwordRequest');

Route::get('/home', 'HomeController@index')->name('home');

Route::group(['middleware' => ['auth']], function() {
    Route::resource('home','HomeController');
    Route::resource('roles','RoleController');
    Route::resource('permissions','PermissionController');
    Route::resource('users','UserController');
    Route::resource('categories','CategoryController');
    Route::resource('socialusers','SocialUsersController');
    Route::resource('sponsers','SponsersController');
    Route::resource('usertokens','UserTokensController');
    Route::resource('tags','TagController');
});