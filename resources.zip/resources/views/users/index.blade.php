@extends('layouts.app')

@section('content')

<div class="breadcrumbs">
    <div class="breadcrumbs-inner">
        <div class="row m-0">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Users Management</h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Users Management</a></li>
                            <li class="active">List</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="content">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                @if ($message = Session::get('success'))
                <div class="alert alert-success">
                  <p>{{ $message }}</p>
                </div>
                @endif
            </div>    
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title">Users List</strong>
                        @can('user-create')
                        <div class="pull-right">
                            <a class="btn btn-success" href="{{ route('users.create') }}"> Create New User</a>
                        </div>
                         @endcan
                    </div>
                    
                    <div class="card-body">
                        <table id="bootstrap-data-table" class="table table-striped table-bordered">
						<thead>
							 <tr>
							   <th>No</th>
							   <th>UserName</th>
							   <th>Email</th>
							   <th>User Profile</th>
							   <th>Country Code</th>
							   <th>Phone Number</th>
							   <th>Email Verified</th>
							   <th>Roles</th>
							   <th width="350px">Action</th>
							 </tr>
						 </thead>
						 <tbody>
                         @foreach ($data as $key => $user)
                          <tr>
                            <td>{{ ++$i }}</td>
                            <td>{{ $user->username }}</td>
                            <td>{{ $user->email }}</td>
                            <td><img src="{{ $user->avatar }}" width="50px"></td>
                            <td>{{ $user->country_code }}</td>
                            <td>{{ $user->phone }}</td>
                            <td>@if($user->email_verified == 1)
								verified
								@else
								 unverified
								@endif
							</td>
                            <td>
                              @if(!empty($user->getRoleNames()))
                                @foreach($user->getRoleNames() as $v)
                                   <label class="badge badge-success">{{ $v }}</label>
                                @endforeach
                              @endif
                            </td>
                            <td>
                               <a class="btn btn-sm" href="{{ route('users.show',$user->id) }}"><i class="fa fa-eye"></i></a>
                                @can('user-edit')
                               <a class="btn btn-sm" href="{{ route('users.edit',$user->id) }}"><i class="fa fa-edit"></i></a>
                                @endcan
                                @can('user-delete')
								<a class="btn btn-sm waves-effect waves-light remove-record" data-toggle="modal" data-url="{!! URL::route('users.destroy', $user->id) !!}" data-id="{{$user->id}}" data-target="#custom-width-modal"><i class="fa fa-trash-o"></i></a>
                             
                                @endcan
								@can('user-edit')
								@if(!empty($user->getRoleNames()))
									@foreach($user->getRoleNames() as $v)
										@if($v == 'Store')
											<a class="btn btn-warning" href="{{ route('users.assign',$user->id) }}">Assign Products</a>
										@endif
									@endforeach
								@endif
								@endcan
                            </td>
                          </tr>
                         @endforeach
						 </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- .animated -->
</div><!-- .content -->
<form action="" method="POST" class="remove-record-model">
    <div id="custom-width-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="custom-width-modalLabel" aria-hidden="true" style="display: none;">
        <div class="modal-dialog" style="width:55%;">
            <div class="modal-content" style="text-align: center;">                
                <div class="modal-body">
					<p></p>
                     <h5>Are you sure you wants to delete?</h5>
					<p></p>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary waves-effect waves-light">Yes, Delete it!</button>
                    <button type="button" class="btn btn-default waves-effect remove-data-from-delete-form" data-dismiss="modal">No Cancel!</button>
                </div>
            </div>
        </div>
    </div>
</form>
@endsection