@extends('layouts.app')

@section('content')

<div class="breadcrumbs">
    <div class="breadcrumbs-inner">
        <div class="row m-0">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>HashTags Management</h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">HashTags Management</a></li>
                            <li class="active">List</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="content">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                @if ($message = Session::get('success'))
                <div class="alert alert-success">
                  <p>{{ $message }}</p>
                </div>
                @endif
            </div>    
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title">HashTags List</strong>
                        @can('tags-create')
                        <div class="pull-right">
                            <a class="btn btn-success" href="{{ route('tags.create') }}"> Create New HashTags</a>
                        </div>
                         @endcan
                    </div>
                    
                    <div class="card-body">
                    <table id="bootstrap-data-table" class="table table-striped table-bordered">
						<thead>
						<tr>
							 <th>No</th>
							 <th>Title</th>
							 <th width="280px">Action</th>
						</tr>
					  </thead>
					  <tbody>
                        @foreach ($tags as $key => $tag)
                        <tr>
                            <td>{{ ++$i }}</td>
                            <td>{{ $tag->title }}</td>
                            <td>
                                <a class="btn btn-sm" href="{{ route('tags.show',$tag->id) }}"><i class="fa fa-eye"></i></a>
                                @can('tags-edit')
                                    <a class="btn btn-sm" href="{{ route('tags.edit',$tag->id) }}"><i class="fa fa-edit"></i></a>
                                @endcan
                                @can('tags-delete')
								<a class="btn btn-sm waves-effect waves-light remove-record" data-toggle="modal" data-url="{!! URL::route('tags.destroy', $tag->id) !!}" data-id="{{$tag->id}}" data-target="#custom-width-modal"><i class="fa fa-trash-o"></i></a>
                                @endcan
                            </td>
                        </tr>
                        @endforeach
						</tbody>
                    </table>
                   
                    </div>
                </div>
            </div>
        </div>
    </div><!-- .animated -->
</div><!-- .content -->
<form action="" method="POST" class="remove-record-model">
    <div id="custom-width-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="custom-width-modalLabel" aria-hidden="true" style="display: none;">
        <div class="modal-dialog" style="width:55%;">
            <div class="modal-content" style="text-align: center;">                
                <div class="modal-body">
					<p></p>
                     <h5>Are you sure you wants to delete?</h5>
					<p></p>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary waves-effect waves-light">Yes, Delete it!</button>
                    <button type="button" class="btn btn-default waves-effect remove-data-from-delete-form" data-dismiss="modal">No Cancel!</button>
                </div>
            </div>
        </div>
    </div>
</form>
@endsection